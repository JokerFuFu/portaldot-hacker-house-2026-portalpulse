import assert from 'node:assert/strict';
import {test as nodeTest} from 'node:test';
const test=(name,fn)=>nodeTest(name,()=>{assert.equal(typeof core.evaluateExecutionEvidence,'function','missing evaluator API');assert.equal(typeof core.parseExecutionEvidence,'function','missing parser API');fn();});
import * as core from '../dist/core/index.js';
const hash = c => '0x' + c.repeat(64);
const genesis=hash('a'), tx=hash('b'), inclusion={hash:hash('c'),number:'100',parentHash:hash('e')}, finalized={hash:hash('d'),number:'101',parentHash:hash('c')};
const at='2026-10-14T00:00:00.000Z';
function fixture(){return {executionSchemaVersion:1,origin:'simulated',network:{id:'simulated-execution',name:'Simulated execution fixture',source:'Manually derived synthetic facts; not Portaldot observations',endpointAlias:'simulated-offline',kind:'event-testnet',expectedGenesis:genesis,observedGenesis:genesis},intent:{vm:'revive',contract:'simulated-probe',caller:'simulated-caller',expectedSequence:'9007199254740993'},submitted:{transactionHash:tx,observedAt:at},inclusion:{transactionHash:tx,block:{...inclusion},transactionIndex:0,transactions:[tx],observedAt:at},execution:{transactionHash:tx,blockHash:inclusion.hash,transactionIndex:0,outcome:'success',failureReason:null,observedAt:at},finality:{genesisHash:genesis,finalized:{...finalized},ancestry:[{...finalized},{...inclusion}],observedAt:at},readback:{genesisHash:genesis,blockHash:finalized.hash,contract:'simulated-probe',caller:'simulated-caller',sequence:'9007199254740993',observedAt:at}};}
const evaluate = value => core.evaluateExecutionEvidence(value);
const parse = text => core.parseExecutionEvidence(text);
test('complete synthetic flow preserves uint64 precision and never claims live/full verification',()=>{const r=evaluate(fixture());assert.equal(r.evidenceComplete,true);assert.equal(r.status,'normal');assert.equal(r.mode,'offline');assert.equal(r.origin,'simulated');assert.equal(r.fullVerification,false);assert.equal(r.verifiedNetwork,false);assert.equal(r.writeAllowed,false);assert.equal(r.observedSequence,'9007199254740993');assert.match(r.trust,/offline/i);assert.match(r.trust,/simulated/i);assert.deepEqual(Object.values(r.checks).map(c=>c.state),Array(6).fill('normal'));});
for(const [stage,check] of [['submitted','submission'],['inclusion','inclusion'],['execution','execution'],['finality','finality'],['readback','state']])test('missing '+stage+' cannot be inferred from later evidence',()=>{const f=fixture();f[stage]=null;const r=evaluate(f);assert.equal(r.checks[check].state,'unverified');assert.equal(r.status,'unverified');assert.equal(r.evidenceComplete,false);const checks=Object.values(r.checks);for(const c of checks.slice(['network','submission','inclusion','execution','finality','state'].indexOf(check)))assert.notEqual(c.state,'normal');});
for(const key of ['expectedGenesis','observedGenesis'])test('missing '+key+' leaves downstream checks unverified',()=>{const f=fixture();f.network[key]=null;const r=evaluate(f);assert.equal(r.status,'unverified');assert.equal(r.checks.network.state,'unverified');assert.notEqual(r.checks.state.state,'normal');});
for(const kind of ['mainnet-readonly','custom-readonly'])test(kind+' is abnormal for execution even with matching genesis',()=>{const f=fixture();f.network.kind=kind;assert.equal(evaluate(f).checks.network.state,'abnormal');});
const abnormalCases=[
 ['wrong observed genesis','network',f=>f.network.observedGenesis=hash('f')],
 ['documented mainnet genesis mislabeled as testnet','network',f=>{f.network.expectedGenesis=f.network.observedGenesis='0x83b5212c69f85f3996f8696bb35bf913af51b176a5f53d0a74fd3a83dc0b8a54';}],
 ['other inclusion transaction','inclusion',f=>f.inclusion.transactionHash=hash('f')],
 ['transaction list mismatch','inclusion',f=>f.inclusion.transactions[0]=hash('f')],
 ['execution for another transaction','execution',f=>f.execution.transactionHash=hash('f')],
 ['execution in another block','execution',f=>f.execution.blockHash=hash('f')],
 ['execution at another index','execution',f=>f.execution.transactionIndex=1],
 ['failed execution with matching state','execution',f=>{f.execution.outcome='failure';f.execution.failureReason='Synthetic failure';}],
 ['unlinked higher finalized block','finality',f=>{f.finality.finalized.parentHash=hash('f');f.finality.ancestry[0].parentHash=hash('f');}],
 ['wrong finality genesis','finality',f=>f.finality.genesisHash=hash('f')],
 ['missing finality path','finality',f=>f.finality.ancestry=[]],
 ['duplicate ancestry cycle','finality',f=>f.finality.ancestry=[f.finality.finalized,f.finality.finalized,f.inclusion.block]],
 ['reordered ancestry','finality',f=>f.finality.ancestry.reverse()],
 ['path omits finalized block','finality',f=>f.finality.ancestry.shift()],
 ['path inclusion height mismatch','finality',f=>f.finality.ancestry[1].number='99'],
 ['path inclusion parent mismatch','finality',f=>f.finality.ancestry[1].parentHash=hash('f')],
 ['path starts with wrong finalized parent','finality',f=>f.finality.ancestry[0].parentHash=hash('f')],
 ['height gap despite linked hashes','finality',f=>{f.finality.finalized.number='102';f.finality.ancestry[0].number='102';}],
 ...['caller','contract','genesisHash','blockHash','sequence'].map(key=>['wrong readback '+key,'state',f=>{f.readback[key]=key.endsWith('Hash')?hash('f'):key==='sequence'?'0':'other-synthetic';}]),
];
for(const [name,check,change] of abnormalCases)test(name+' remains abnormal and blocks downstream normal',()=>{const f=fixture();change(f);const r=evaluate(f);assert.equal(r.checks[check].state,'abnormal');assert.equal(r.status,'abnormal');assert.equal(r.evidenceComplete,false);for(const c of Object.values(r.checks).slice(['network','submission','inclusion','execution','finality','state'].indexOf(check)+1))assert.notEqual(c.state,'normal');});
test('explicit execution failure remains abnormal when submission is missing',()=>{const f=fixture();f.submitted=null;f.execution.outcome='failure';f.execution.failureReason='Synthetic failed call';assert.equal(evaluate(f).checks.execution.state,'abnormal');});
test('same-block finalized path of one exact block is sufficient',()=>{const f=fixture();f.finality.finalized={...f.inclusion.block};f.finality.ancestry=[{...f.inclusion.block}];f.readback.blockHash=f.inclusion.block.hash;assert.equal(evaluate(f).evidenceComplete,true);});
for(const value of ['0','9007199254740991','9007199254740992','9007199254740993','18446744073709551615'])test('canonical sequence '+value+' is compared without Number rounding',()=>{const f=fixture();f.intent.expectedSequence=f.readback.sequence=value;assert.equal(evaluate(f).observedSequence,value);assert.equal(evaluate(f).evidenceComplete,true);f.readback.sequence=value==='0'?'1':'0';assert.equal(evaluate(f).status,'abnormal');});
test('zero readback alone cannot prove update execution',()=>{const f=fixture();f.intent.expectedSequence=f.readback.sequence='0';f.execution=null;assert.equal(evaluate(f).status,'unverified');});
const invalidCases=[
 ['unknown top field',f=>f.extra=true],['missing required null stage key',f=>delete f.submitted],['wrong schema version',f=>f.executionSchemaVersion=2],['bad origin',f=>f.origin='live'],['bad VM',f=>f.intent.vm='unknown'],['unknown intent field',f=>f.intent.extra=1],['unknown network endpoint',f=>f.network.endpoint=null],['unknown block field',f=>f.inclusion.block.extra=1],['nonfinite index',f=>f.inclusion.transactionIndex=Infinity],['NaN index',f=>f.execution.transactionIndex=NaN],['unsafe index',f=>f.execution.transactionIndex=9007199254740992],['fractional index',f=>f.inclusion.transactionIndex=0.5],['negative index',f=>f.inclusion.transactionIndex=-1],['index out of bounds',f=>f.inclusion.transactionIndex=1],['sparse transactions',f=>f.inclusion.transactions=new Array(1)],['too many transactions',f=>f.inclusion.transactions=Array(8193).fill(tx)],['sparse ancestry',f=>f.finality.ancestry=new Array(1)],['too many ancestry blocks',f=>f.finality.ancestry=Array(513).fill(inclusion)],['noncanonical height',f=>f.inclusion.block.number='0100'],['negative height',f=>f.inclusion.block.number='-1'],['oversize height',f=>f.inclusion.block.number='1'.repeat(310)],['short hash',f=>f.submitted.transactionHash='0xbb'],['address control characters',f=>f.intent.caller='caller\n'],['URL address',f=>f.intent.contract='https://synthetic.invalid/probe'],['compact URL address',f=>f.intent.caller='https:synthetic.invalid'],['oversize address',f=>f.intent.caller='c'.repeat(129)],['empty address',f=>f.intent.contract=''],['failure without reason',f=>f.execution.outcome='failure'],['success with failure reason',f=>f.execution.failureReason='Unexpected'],['empty failure reason',f=>{f.execution.outcome='failure';f.execution.failureReason='';}],['oversize failure reason',f=>{f.execution.outcome='failure';f.execution.failureReason='x'.repeat(513);}],['bad timestamp',f=>f.submitted.observedAt='2026-02-30T00:00:00.000Z'],['noncanonical timestamp',f=>f.submitted.observedAt='2026-10-14T00:00:00Z'],['time regression',f=>f.inclusion.observedAt='2026-10-13T23:59:59.000Z'],['regression across missing stages',f=>{f.inclusion=null;f.execution.observedAt='2026-10-13T23:59:59.000Z';}],['custom prototype',f=>Object.setPrototypeOf(f.intent,{})],['symbol field',f=>f.intent[Symbol('extra')]=1],['array extra key',f=>f.inclusion.transactions.extra=1],['accessor input',f=>Object.defineProperty(f.intent,'vm',{enumerable:true,get(){throw new Error('getter ran');}})],
 ...['18446744073709551616','01','-1','1.0','1e3',''].map(v=>['invalid uint64 '+v,f=>f.intent.expectedSequence=v]),
];
for(const [name,change] of invalidCases)test('strict validation rejects '+name,()=>{const f=fixture();change(f);assert.throws(()=>evaluate(f));});
test('accepted boundary sizes and height width are retained',()=>{const f=fixture();f.inclusion.transactions=Array(8192).fill(tx);f.inclusion.block.number='1'.repeat(309);f.finality=null;f.readback=null;f.intent.contract='p'.repeat(128);assert.equal(evaluate(f).checks.inclusion.state,'normal');});
test('dense 512-block ancestry is accepted structurally but inconsistent path stays abnormal',()=>{const f=fixture();f.finality.ancestry=Array.from({length:512},()=>({...inclusion}));assert.equal(evaluate(f).checks.finality.state,'abnormal');});
test('all hashes and hex20 addresses compare case-insensitively',()=>{const f=fixture();f.intent.contract='0x'+'ab'.repeat(20);f.readback.contract='0x'+'AB'.repeat(20);f.submitted.transactionHash='0x'+'B'.repeat(64);f.network.expectedGenesis='0x'+'A'.repeat(64);assert.equal(evaluate(f).evidenceComplete,true);});
test('opaque native addresses remain case-sensitive without mapping',()=>{const f=fixture();f.readback.caller='SIMULATED-caller';assert.equal(evaluate(f).checks.state.state,'abnormal');});
test('RPC provenance never changes offline trust flags',()=>{const f=fixture();f.origin='rpc';const r=evaluate(f);assert.equal(r.status,'normal');assert.equal(r.origin,'rpc');assert.equal(r.fullVerification,false);assert.equal(r.verifiedNetwork,false);assert.match(r.trust,/rpc/i);});
test('validator detaches nested arrays and blocks from later input mutation',()=>{const f=fixture();const parsed=parse(JSON.stringify(f));const r=evaluate(parsed);parsed.inclusion.transactions[0]=hash('f');parsed.finality.ancestry[0].number='200';parsed.readback.sequence='0';assert.equal(r.status,'normal');assert.equal(r.observedSequence,'9007199254740993');assert.equal(f.inclusion.transactions[0],tx);});
test('direct validation does not mutate frozen evidence',()=>{const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}return v;};assert.equal(evaluate(freeze(fixture())).status,'normal');});
test('parser rejects malformed JSON concisely without echoing private input',()=>{assert.throws(()=>parse('{"private":"DO-NOT-ECHO"'),error=>error.message.length<200&&!error.message.includes('DO-NOT-ECHO'));});
test('parser rejects actual UTF8 byte overflow, not only JS character length',()=>{const text=JSON.stringify(fixture())+' '.repeat(1024*1024);assert.throws(()=>parse(text));assert.throws(()=>parse('é'.repeat(524289)));});
test('parser accepts exactly 1MiB of valid JSON padded with whitespace',()=>{const text=JSON.stringify(fixture());assert.equal(parse(text+' '.repeat(1048576-Buffer.byteLength(text))).origin,'simulated');});
test('parser validates nonfinite JSON exponent',()=>{const text=JSON.stringify(fixture()).replace('"transactionIndex":0','"transactionIndex":1e999');assert.throws(()=>parse(text));});
test('terminal inclusion parent cannot cycle back to a finalized ancestor',()=>{const f=fixture();f.inclusion.block.parentHash=f.finality.finalized.hash;f.finality.ancestry[1].parentHash=f.finality.finalized.hash;assert.equal(evaluate(f).checks.finality.state,'abnormal');});
test('one-block finality cannot use a self-parent cycle',()=>{const f=fixture();f.inclusion.block.parentHash=f.inclusion.block.hash;f.finality.finalized={...f.inclusion.block};f.finality.ancestry=[{...f.inclusion.block}];f.readback.blockHash=f.inclusion.block.hash;assert.equal(evaluate(f).checks.finality.state,'abnormal');});
test('contradictory inclusion remains abnormal without submitted evidence',()=>{
  const f=fixture();
  f.submitted=null;
  f.inclusion.transactions[0]=hash('f');
  const r=evaluate(f);
  assert.equal(r.checks.submission.state,'unverified');
  assert.equal(r.checks.inclusion.state,'abnormal');
  assert.equal(r.status,'abnormal');
  assert.equal(r.evidenceComplete,false);
  assert.equal(r.observedSequence,'9007199254740993');
  for(const key of ['execution','finality','state'])assert.notEqual(r.checks[key].state,'normal');
});
test('consistent inclusion remains unverified without submitted evidence',()=>{
  const f=fixture();
  f.submitted=null;
  const r=evaluate(f);
  assert.equal(r.checks.inclusion.state,'unverified');
  assert.equal(r.status,'unverified');
  assert.equal(r.evidenceComplete,false);
});
const partialIdentityCases=[
  ['execution versus submission without inclusion','execution',f=>{f.inclusion=null;f.execution.transactionHash=hash('f');}],
  ['finality versus expected genesis without observed genesis','finality',f=>{f.network.observedGenesis=null;f.finality.genesisHash=hash('f');}],
  ['finality versus observed genesis without expected genesis','finality',f=>{f.network.expectedGenesis=null;f.finality.genesisHash=hash('f');}],
  ['readback versus expected genesis without observed genesis or finality','state',f=>{f.network.observedGenesis=null;f.finality=null;f.readback.genesisHash=hash('f');}],
  ['readback versus observed genesis without expected genesis or finality','state',f=>{f.network.expectedGenesis=null;f.finality=null;f.readback.genesisHash=hash('f');}],
  ['readback versus finality without observed genesis','state',f=>{f.network.observedGenesis=null;f.readback.genesisHash=hash('f');}],
  ['readback versus finality without either network genesis','state',f=>{f.network.expectedGenesis=null;f.network.observedGenesis=null;f.readback.genesisHash=hash('f');}],
  ['expected versus observed genesis without finality or readback','network',f=>{f.finality=null;f.readback=null;f.network.observedGenesis=hash('f');}],
];
for(const [name,key,change] of partialIdentityCases)test('partial identity contradiction: '+name,()=>{
  const f=fixture();change(f);
  const r=evaluate(f);
  assert.equal(r.checks[key].state,'abnormal');
  assert.equal(r.status,'abnormal');
  assert.equal(r.evidenceComplete,false);
  assert.equal(r.mode,'offline');
  for(const flag of ['verifiedNetwork','writeAllowed','fullVerification'])assert.equal(r[flag],false);
  assert.equal(r.expectedSequence,'9007199254740993');
  assert.equal(r.observedSequence,f.readback===null?null:'9007199254740993');
  for(const downstream of ['inclusion','execution','finality','state'])assert.notEqual(r.checks[downstream].state,'normal');
});
const partialIdentityControls=[
  ['inclusion',f=>f.inclusion=null],
  ['observed genesis',f=>f.network.observedGenesis=null],
  ['expected genesis',f=>f.network.expectedGenesis=null],
  ['observed genesis and finality',f=>{f.network.observedGenesis=null;f.finality=null;}],
  ['expected genesis and finality',f=>{f.network.expectedGenesis=null;f.finality=null;}],
  ['both network genesis values',f=>{f.network.expectedGenesis=null;f.network.observedGenesis=null;}],
  ['finality and readback',f=>{f.finality=null;f.readback=null;}],
];
for(const [name,change] of partialIdentityControls)test('matching identities stay unverified with missing '+name,()=>{
  const f=fixture();change(f);
  // Available identities may differ only in hex letter case.
  f.submitted.transactionHash=hash('B');
  if(f.network.expectedGenesis!==null)f.network.expectedGenesis=hash('A');
  if(f.finality)f.finality.genesisHash=hash('A');
  const r=evaluate(f);
  assert.equal(r.status,'unverified');
  assert.equal(r.evidenceComplete,false);
  assert.equal(r.mode,'offline');
  for(const flag of ['verifiedNetwork','writeAllowed','fullVerification'])assert.equal(r[flag],false);
  for(const key of ['finality','state'])assert.equal(r.checks[key].state,'unverified');
});
test('explicit failure reason takes precedence over direct transaction mismatch without inclusion',()=>{
  const f=fixture();f.inclusion=null;f.execution.transactionHash=hash('f');f.execution.outcome='failure';f.execution.failureReason='Synthetic explicit failure';
  const r=evaluate(f);
  assert.equal(r.checks.execution.state,'abnormal');
  assert.match(r.checks.execution.reason,/Synthetic explicit failure/);
  assert.equal(r.status,'abnormal');
  assert.equal(r.evidenceComplete,false);
});
