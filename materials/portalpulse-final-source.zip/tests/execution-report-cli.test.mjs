import assert from 'node:assert/strict';
import {test} from 'node:test';
import {spawnSync} from 'node:child_process';
import {readFile,mkdtemp,writeFile,rm,access,mkdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const run=(...args)=>spawnSync(process.execPath,['dist/cli/main.js',...args],{encoding:'utf8',timeout:5000});
async function setup(t,mutate){const dir=await mkdtemp(join(tmpdir(),'portalpulse-report-'));t.after(()=>rm(dir,{recursive:true,force:true}));const e=JSON.parse(await readFile('examples/execution-simulated.example.json','utf8'));mutate?.(e);const input=join(dir,'input.json'),out=join(dir,'report.json');await writeFile(input,JSON.stringify(e));return {dir,input,out,e};}
function summary(result,exit,status){assert.equal(result.status,exit,result.stderr);assert.equal(result.signal,null);assert.equal(result.stderr,'');const s=JSON.parse(result.stdout);assert.equal(s.status,status);assert.equal(s.mode,'offline');assert.equal(s.origin,'simulated');assert.equal(s.expectedSequence,'9007199254740993');for(const flag of ['fullVerification','verifiedNetwork','writeAllowed'])assert.equal(s[flag],false);return s;}
for(const [name,exit,status,mutate] of [['complete',0,'normal',()=>{}],['partial',2,'unverified',e=>e.execution=null],['abnormal',1,'abnormal',e=>{e.execution.outcome='failure';e.execution.failureReason='Synthetic failure';}],['contradiction with absent stage',1,'abnormal',e=>{e.submitted=null;e.inclusion.transactions[0]='0x'+'f'.repeat(64);}]] )test('CLI exports and inspects retained '+name+' diagnostic envelope',async t=>{const {input,out,e}=await setup(t,mutate);const raw=summary(run('execution-inspect','--input',input),exit,status);const exported=summary(run('execution-report','--input',input,'--out',out),exit,status);assert.deepEqual(exported,{...raw,report:exported.report});assert.deepEqual(exported.report,{executionReportVersion:1,sha256:exported.report.sha256,integrity:'sha256-content-only; not source authenticity'});assert.match(exported.report.sha256,/^[0-9a-f]{64}$/);const text=await readFile(out,'utf8'),r=JSON.parse(text);assert.equal(text,JSON.stringify(r));assert.ok(Buffer.byteLength(text)<=1048576);assert.deepEqual(r.payload,e);assert.equal(r.sha256,exported.report.sha256);assert.equal(r.payload.readback.observedAt,'2026-10-14T00:00:00.000Z');assert.deepEqual(summary(run('execution-inspect','--input',out),exit,status),exported);});
test('CLI refuses overwrite byte-for-byte and emits no successful stdout',async t=>{const {input,out}=await setup(t);await writeFile(out,'KEEP ORIGINAL\n');const r=run('execution-report','--input',input,'--out',out);assert.equal(r.status,1);assert.equal(r.stdout,'');assert.match(r.stderr,/exists|overwrite/i);assert.equal(await readFile(out,'utf8'),'KEEP ORIGINAL\n');});
for(const [name,text] of [['malformed','{"secret":"DO-NOT-ECHO"'],['unknown schema','{"extra":true}'],['oversize',' '.repeat(1048577)]])test('CLI rejects '+name+' raw input without stdout or output file',async t=>{const {input,out}=await setup(t);await writeFile(input,text);const r=run('execution-report','--input',input,'--out',out);assert.equal(r.status,1);assert.equal(r.stdout,'');assert.match(r.stderr,/invalid|size|limit/i);assert.ok(!r.stderr.includes('DO-NOT-ECHO'));await assert.rejects(access(out));});
test('CLI write error emits no successful summary',async t=>{const {input,out}=await setup(t);await mkdir(out);const r=run('execution-report','--input',input,'--out',join(out,'missing','..','..','input.json','child'));assert.equal(r.status,1);assert.equal(r.stdout,'');assert.match(r.stderr,/ENOTDIR|exists|ENOENT/i);});
for(const args of [[],['--input','x'],['--out','y'],['--input'],['--input','x','--out'],['--input','x','--out','y','--out','z'],['--input','x','--input','z','--out','y'],['--input','x','--out','y','--samples','1'],['--input','x','--out','y','extra']])test('CLI exporter requires exact nonduplicate input/out flags '+args.join(' '),()=>{const r=run('execution-report',...args);assert.equal(r.status,1);assert.equal(r.stdout,'');assert.match(r.stderr,/required|Missing|Duplicate|Unknown option/i);});
for(const [name,mutate] of [['digest',r=>r.sha256='0'.repeat(64)],['origin',r=>r.payload.origin='rpc'],['unsupported version',r=>r.executionReportVersion=2],['mixed raw fields',r=>r.origin='simulated'],['missing envelope fields',r=>delete r.sha256]])test('execution-inspect rejects '+name+' envelope without raw fallback',async t=>{const {input,out}=await setup(t);const created=run('execution-report','--input',input,'--out',out);assert.equal(created.status,0,created.stderr);const r=JSON.parse(await readFile(out,'utf8'));mutate(r);await writeFile(out,JSON.stringify(r));const inspected=run('execution-inspect','--input',out);assert.equal(inspected.status,1);assert.equal(inspected.stdout,'');assert.ok(inspected.stderr);});
test('execution-inspect rejects distinct M1 report; existing M1 inspect still accepts it',async t=>{const {out}=await setup(t);assert.equal(run('demo','--out',out).status,0);const r=run('execution-inspect','--input',out);assert.equal(r.status,1);assert.equal(r.stdout,'');assert.equal(run('inspect','--input',out).status,0);});
test('export command consumes raw evidence only, never an envelope as raw facts',async t=>{const {input,out,dir}=await setup(t);assert.equal(run('execution-report','--input',input,'--out',out).status,0);const second=join(dir,'second.json'),r=run('execution-report','--input',out,'--out',second);assert.equal(r.status,1);assert.equal(r.stdout,'');await assert.rejects(access(second));});


test('CLI raw uppercase genesis inspection and canonical export retain compatible summaries', async t => {
  const {input, out, e} = await setup(t, evidence => {
    evidence.network.expectedGenesis = '0x' + 'A'.repeat(64);
  });
  const raw = summary(run('execution-inspect', '--input', input), 0, 'normal');
  const exported = summary(run('execution-report', '--input', input, '--out', out), 0, 'normal');
  const saved = await readFile(out, 'utf8');
  const report = JSON.parse(saved);

  assert.deepEqual(exported, {...raw, report: exported.report});
  assert.equal(report.payload.network.expectedGenesis, '0x' + 'a'.repeat(64));
  assert.equal(report.sha256, '8d48a5007da2ae06405a1b18ae984d7776c19503f9e9d5be7b04931cb9d71b81');
  assert.deepEqual(report.payload, {...e, network: {...e.network, expectedGenesis: '0x' + 'a'.repeat(64)}});
  assert.deepEqual(summary(run('execution-inspect', '--input', out), 0, 'normal'), exported);
  assert.equal(await readFile(out, 'utf8'), saved);
  assert.equal(JSON.parse(await readFile(input, 'utf8')).network.expectedGenesis, '0x' + 'A'.repeat(64));
});

test('CLI rejects same-digest changed-case envelope and preserves the saved report', async t => {
  const {input, out, dir} = await setup(t);
  summary(run('execution-report', '--input', input, '--out', out), 0, 'normal');
  const saved = await readFile(out, 'utf8');
  const report = JSON.parse(saved);
  report.payload.network.expectedGenesis = '0x' + 'A'.repeat(64);
  const tampered = join(dir, 'changed-case.json');
  const text = JSON.stringify(report);
  await writeFile(tampered, text);

  const result = run('execution-inspect', '--input', tampered);
  assert.equal(result.status, 1, result.stdout);
  assert.equal(result.signal, null);
  assert.equal(result.error, undefined);
  assert.equal(result.stdout, '');
  assert.match(result.stderr, /integrity|invalid/i);
  assert.equal(await readFile(out, 'utf8'), saved);
  assert.equal(await readFile(tampered, 'utf8'), text);
});
