import assert from 'node:assert/strict';
import {test} from 'node:test';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import * as core from '../dist/core/index.js';
import {makeDemoSession} from '../dist/demo/session.js';
const fixture=JSON.parse(await readFile('examples/execution-simulated.example.json','utf8'));
const fresh=()=>structuredClone(fixture);
function api(){assert.equal(typeof core.createExecutionReport,'function','execution report creation must be available');assert.equal(typeof core.importExecutionReport,'function','execution report import must be available');}
function canonical(value){if(value===null||typeof value!=='object')return JSON.stringify(value);if(Array.isArray(value))return '['+value.map(canonical).join(',')+']';return '{'+Object.keys(value).sort().map(key=>JSON.stringify(key)+':'+canonical(value[key])).join(',')+'}';}
function resign(report){report.sha256=createHash('sha256').update(canonical(report.payload)).digest('hex');return JSON.stringify(report);}
function detached(a,b){if(a&&typeof a==='object'){assert.notEqual(a,b);for(const key of Object.keys(a))detached(a[key],b[key]);}}
function offline(summary,status){assert.equal(summary.status,status);assert.equal(summary.mode,'offline');assert.equal(summary.expectedSequence,'9007199254740993');for(const flag of ['fullVerification','writeAllowed','verifiedNetwork'])assert.equal(summary[flag],false);}
test('M1 fixed demo retains its pre-extraction literal canonical SHA-256',async()=>{const {config,samples}=makeDemoSession();const r=await core.createReport(config,samples,{origin:'simulated'});assert.equal(r.sha256,'6bbce53e82846430f03f661a9c3b54ff5d0255e9dc86e018b5a1475d0a12a661');assert.deepEqual(await core.importReport(JSON.stringify(r)),r);});
test('execution report roundtrip preserves the complete synthetic evidence and uint64 sequence',async()=>{api();const e=fresh(),r=await core.createExecutionReport(e);assert.deepEqual(Object.keys(r).sort(),['executionReportVersion','payload','sha256']);assert.equal(r.executionReportVersion,1);assert.match(r.sha256,/^[0-9a-f]{64}$/);assert.deepEqual(r.payload,e);assert.equal(r.payload.intent.expectedSequence,'9007199254740993');assert.equal(r.payload.submitted.observedAt,'2026-10-14T00:00:00.000Z');const imported=await core.importExecutionReport(JSON.stringify(r));assert.deepEqual(imported,r);detached(r.payload,e);detached(imported,r);offline(core.evaluateExecutionEvidence(imported.payload),'normal');});
test('validated evidence API detaches nested objects and arrays without serialization',()=>{assert.equal(typeof core.validateExecutionEvidence,'function');const e=fresh(),v=core.validateExecutionEvidence(e);assert.deepEqual(v,e);detached(v,e);v.finality.ancestry[0].number='102';assert.equal(e.finality.ancestry[0].number,'101');});
test('capture before first await protects report payload from caller mutation',async()=>{api();const e=fresh(),promise=core.createExecutionReport(e);e.origin='rpc';e.network.source='changed';e.intent.expectedSequence='42';e.submitted.observedAt='2026-10-15T00:00:00.000Z';e.inclusion.transactions[0]='0x'+'f'.repeat(64);e.finality.ancestry[0].number='999';e.readback.sequence='42';const r=await promise;assert.deepEqual(r.payload,fixture);await core.importExecutionReport(JSON.stringify(r));});
test('report/import results are independent of previous returned object mutations',async()=>{api();const e=fresh(),r=await core.createExecutionReport(e),text=JSON.stringify(r),a=await core.importExecutionReport(text),b=await core.importExecutionReport(text);a.payload.network.source='changed';a.payload.finality.ancestry.length=0;r.payload.intent.expectedSequence='42';assert.deepEqual(b.payload,e);});
test('recursive object key order leaves payload digest stable; array order remains significant',async()=>{api();function reverse(v){if(Array.isArray(v))return v.map(reverse);if(v&&typeof v==='object')return Object.fromEntries(Object.entries(v).reverse().map(([k,x])=>[k,reverse(x)]));return v;}const a=await core.createExecutionReport(fresh()),b=await core.createExecutionReport(reverse(fresh()));assert.equal(a.sha256,b.sha256);assert.deepEqual((await core.importExecutionReport(JSON.stringify(reverse(a)))).payload,a.payload);const e=fresh();e.inclusion.transactions.push('0x'+'f'.repeat(64));const c=await core.createExecutionReport(e);e.inclusion.transactions.reverse();const d=await core.createExecutionReport(e);assert.notEqual(c.sha256,d.sha256);});
for(const [name,mutate] of [
 ['nonfinite index',e=>e.execution.transactionIndex=Infinity],['NaN index',e=>e.inclusion.transactionIndex=NaN],['unknown undefined',e=>e.extra=undefined],['symbol field',e=>e[Symbol('hidden')]=true],['hidden field',e=>Object.defineProperty(e,'extra',{value:true})],['sparse transactions',e=>delete e.inclusion.transactions[0]],['sparse ancestry',e=>delete e.finality.ancestry[0]],['array extra',e=>e.finality.ancestry.extra=true],['unknown nested',e=>e.network.endpoint='https://synthetic.invalid'],['forged status',e=>e.status='normal'],['forged full verification',e=>e.fullVerification=true],['forged mode',e=>e.mode='live'],['forged network verification',e=>e.verifiedNetwork=true],
])test('creation rejects '+name+' before lossy JSON serialization',async()=>{api();const e=fresh();mutate(e);await assert.rejects(core.createExecutionReport(e),/invalid/i);});
test('accessors and toJSON cannot erase or replace invalid caller facts',async()=>{api();for(const field of ['network','intent','submitted','inclusion','execution','finality','readback']){const e=fresh();let reads=0;Object.defineProperty(e,field,{enumerable:true,get(){reads++;return fixture[field];}});await assert.rejects(core.createExecutionReport(e),/invalid/i);assert.equal(reads,0);}const e=fresh();let calls=0;e.toJSON=()=>{calls++;return fixture;};await assert.rejects(core.createExecutionReport(e),/invalid/i);assert.equal(calls,0);const nested=fresh();Object.defineProperty(nested.inclusion.transactions,'0',{enumerable:true,get(){throw Error('must not invoke getter');}});await assert.rejects(core.createExecutionReport(nested),/invalid/i);});
for(const [name,mutate] of [
 ['unsupported version',r=>r.executionReportVersion=2],['missing version',r=>delete r.executionReportVersion],['wrong version type',r=>r.executionReportVersion='1'],['unknown root',r=>r.extra=true],['mixed M1 field',r=>r.schemaVersion=1],['mixed raw field',r=>r.origin='rpc'],['short digest',r=>r.sha256='0'.repeat(63)],['uppercase digest',r=>r.sha256='A'.repeat(64)],['non-string digest',r=>r.sha256=null],['missing payload',r=>delete r.payload],['forged summary',r=>r.summary={status:'normal'}],['forged payload status',r=>r.payload.status='normal'],['forged payload verification',r=>r.payload.fullVerification=true],['invalid payload version',r=>r.payload.executionSchemaVersion=2],
])test('strict import rejects '+name,async()=>{api();const r=await core.createExecutionReport(fresh());mutate(r);await assert.rejects(core.importExecutionReport(JSON.stringify(r)),/invalid|version|digest/i);});
test('valid digest cannot legitimize forged or unknown evidence fields',async()=>{api();for(const field of ['status','fullVerification','verifiedNetwork','mode']){const r=await core.createExecutionReport(fresh());r.payload[field]=field==='status'?'normal':true;await assert.rejects(core.importExecutionReport(resign(r)),/invalid/i);}});
for(const [name,mutate] of [['payload sequence',r=>r.payload.intent.expectedSequence='42'],['digest',r=>r.sha256='0'.repeat(64)],['same-digest changed origin',r=>r.payload.origin='rpc'],['collection time',r=>r.payload.readback.observedAt='2026-10-15T00:00:00.000Z']])test('integrity detects '+name+' alteration',async()=>{api();const r=await core.createExecutionReport(fresh());mutate(r);await assert.rejects(core.importExecutionReport(JSON.stringify(r)),/digest|integrity/i);});
test('complete imported text counts UTF-8 bytes inclusively at 1 MiB',async()=>{api();const e=fresh();e.network.source='Synthetic Unicode '+'😃'.repeat(100);const r=await core.createExecutionReport(e),text=JSON.stringify(r),padding=' '.repeat(1048576-Buffer.byteLength(text)),exact=text+padding;assert.equal(Buffer.byteLength(exact),1048576);assert.ok(exact.length<1048576);assert.deepEqual(await core.importExecutionReport(exact),r);await assert.rejects(core.importExecutionReport(exact+' '),/size|limit|1 MiB/i);});
test('malformed JSON, non-text and distinct M1 envelope fail execution report import',async()=>{api();for(const text of ['{','null','[]','{}',null])await assert.rejects(core.importExecutionReport(text),/invalid|JSON|limit/i);const {config,samples}=makeDemoSession();await assert.rejects(core.importExecutionReport(JSON.stringify(await core.createReport(config,samples))),/invalid/i);});
for(const [name,status,mutate] of [['missing execution','unverified',e=>e.execution=null],['missing prior submission','unverified',e=>e.submitted=null],['failed execution','abnormal',e=>{e.execution.outcome='failure';e.execution.failureReason='Synthetic failure';}],['readback mismatch','abnormal',e=>e.readback.sequence='42'],['contradictory inclusion without submission','abnormal',e=>{e.submitted=null;e.inclusion.transactions[0]='0x'+'f'.repeat(64);}]] )test('diagnostic report retains '+name,async()=>{api();const e=fresh();mutate(e);const r=await core.importExecutionReport(JSON.stringify(await core.createExecutionReport(e)));assert.deepEqual(r.payload,e);offline(core.evaluateExecutionEvidence(r.payload),status);});
test('rpc-origin evidence retains origin while every verification flag stays false',async()=>{api();const e=fresh();e.origin='rpc';const r=await core.importExecutionReport(JSON.stringify(await core.createExecutionReport(e)));assert.equal(r.payload.origin,'rpc');offline(core.evaluateExecutionEvidence(r.payload),'normal');});


test('report import rejects changed expectedGenesis casing with the original digest', async () => {
  const report = await core.createExecutionReport(fresh());
  report.payload.network.expectedGenesis = '0x' + 'A'.repeat(64);

  await assert.rejects(
    core.importExecutionReport(JSON.stringify(report)),
    /integrity|invalid/i,
  );
});

test('report import rejects noncanonical payload values even with a recomputed digest', async () => {
  const report = await core.createExecutionReport(fresh());
  report.payload.network.expectedGenesis = '0x' + 'A'.repeat(64);
  const text = resign(report);
  assert.notEqual(report.sha256, '8d48a5007da2ae06405a1b18ae984d7776c19503f9e9d5be7b04931cb9d71b81');

  await assert.rejects(
    core.importExecutionReport(text),
    /invalid.*canonical.*values/i,
  );
});

test('raw uppercase expectedGenesis retains normalization and exports a canonical roundtrip', async () => {
  const evidence = fresh();
  evidence.network.expectedGenesis = '0x' + 'A'.repeat(64);

  const validated = core.validateExecutionEvidence(evidence);
  assert.deepEqual(validated, fixture);
  assert.deepEqual(core.parseExecutionEvidence(JSON.stringify(evidence)), fixture);
  assert.deepEqual(core.evaluateExecutionEvidence(evidence), core.evaluateExecutionEvidence(fixture));

  const report = await core.createExecutionReport(evidence);
  assert.deepEqual(report.payload, fixture);
  assert.equal(report.sha256, '8d48a5007da2ae06405a1b18ae984d7776c19503f9e9d5be7b04931cb9d71b81');
  assert.equal(evidence.network.expectedGenesis, '0x' + 'A'.repeat(64));
  assert.deepEqual(await core.importExecutionReport(JSON.stringify(report)), report);
});
