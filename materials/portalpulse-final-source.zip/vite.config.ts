import {defineConfig} from 'vite';
export default defineConfig({base:'./',build:{outDir:'dist/site'},server:{host:'127.0.0.1'},preview:{host:'127.0.0.1'}});
