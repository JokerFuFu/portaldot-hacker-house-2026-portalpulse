# PortalPulse 时间线与阶段状态

## 4 November 2026 current integration checkpoint

The participant deployed PortalPulseProbe at 0x7a7ceb705bb1886f2d7aee766c6e8ee8a3c42d2d and signed record(1). Exact native events, linked finalized headers, compiled runtime and pinned caller state 1 were captured by the product collector. Actual browser download/reimport, CLI replay and four-page A4 printing passed. [Actual facts and trust limits](live-chain-20261104.md) supersede the pending-probe statements in the historical dated sections below. The browser remains readonly; execution imports remain offline with all three verification/write flags false. Platform final submission has its own [checklist](submission-checklist.md).

状态日期：2026-10-21。只读/离线原型、报告和六类验收预设已实现；99项聚焦/507项全套通过，真实本机网页已读回六场景。[评审指南](reviewer-guide.md)。原型Deck、字幕截图讲解和A4材料保留10/16归属。当前进度材料已于10/20随Build50050提交，最后回读Under Review，尚非审核通过或最终提交。[平台记录](evidence/checkin-submission-20261020.json)。可信网络身份、探针及实链完整执行仍待完成；下方有日期的小节保留历史检查点，不代表当前未提交。

| 日期（2026 年） | 阶段与计划目标 | 状态 |
|---|---|---|
| 10-09 至 10-13 | 准备设计、验收标准、提交清单与开发环境资料；核验 V3 接入条件。所有记录标为准备 | 准备文档与公开快照已完成；旧RPC状态保留历史记录 |
| 10-14 至 10-17 | 在比赛期实现网络适配与监控，产生真实开源代码提交 | 本地只读增量已实施；d58e695 已有独立 Node 22.12 新目录 200 项验证及人工本地 RPC 完整等价 URL 脱敏浏览器专项；紧凑端点旧专项保留 c6bf4a0 归属；其他限定浏览器证据保留 6b24591 归属；下载 / 导入、窄屏、打印 CSS 仍引用 2f1a91e；M1 源码 c333e579 的 43 个远端文件回读一致，Sites 版本 2 已公开部署并完成匿名资产与限定浏览器回读；M2A / M2B 离线源码已公开，最终 M2B 为代码 3e7b607 / 文档 d842530；M2C 本地状态及浏览器证据见下节，原生 Site 已在10/16更新为release3 / M2C，后续材料发布另行留证；真实 V3 与完整验收待完成 |
| 10-14 20:00–22:00（北京时间） | Discord Kick-off Meeting & Workshop | 活动已结束；无本项目参会证据 |
| 10-18 至 10-21 | 在认可测试网上完成新探针部署、执行回读与报告流程 | 尚未部署，可信身份待确认；只读身份/运行时/账户核验已有独立记录，不冒充部署完成 |
| 10-22 至 10-23 | 补齐架构图、README、初期演示与部署证据 | 架构、Deck、原型讲解及文案已在10/16准备；真实部署证据待认可 V3 |
| 10-23 20:00 前（北京时间，内部缓冲） | 完成具体字段复核、本人协议确认、Check-in 提交与回读 | 10/20已提前提交并回读Build50050/Under Review；本人协议完成 |
| 10-24 20:00 前（北京时间） | 在 DoraHacks 完成 Check-in，并回读提交状态 | 当前进度已提交待审核；审核通过未确认，部署证据仍未完成 |
| 10-25 至 11-03 | 根据反馈完善错误处理、复现能力、报告体验与演示 | 未开始 |
| 10-27 00:00（北京时间） | 读取 Check-in 反馈结果，调整后续实施 | 待发布 |
| 10-27 20:00 前（北京时间） | 整理进度、仓库、模块、部署状态、演示及问题，申请 Office Hours | 未申请 |
| 10-28 至 10-29（官方 UTC 日期） | 按正式场次参加 Office Hours | 场次待确认 |
| 11-04 | 完成核心功能版本，避免在截止前最后 24 小时集中提交核心模块 | 未开始 |
| 11-05 | 验收最终代码、演示、最多三分钟视频和 Pitch Deck | 未开始 |
| 11-06 12:00 前（北京时间） | 完成最终提交并回读，进入代码冻结 | 未提交 |
| 11-08 至 11-09（官方 UTC 日期） | Demo Day；具体场次需按官方排期转换北京时间并配合演示 | 场次待确认 |
| 11-10 00:00 至 11-11 00:00（北京时间） | Community Choice Voting；按官方频道规则参加 | 未开始 |
| 11-11（官方 UTC 日期） | 核验获奖结果 | 待公布 |
| 11-12 至 11-14（官方 UTC 日期） | 如获奖，按官方要求提供真实领奖资料 | 未开始；身份资料由本人处理 |
| 11-14 20:00（北京时间） | 主办方计划发奖；实际到账需另行核验 | 计划日期，不代表到账 |

以上以 **2026-10-13 实际读取的[官方详情](https://dorahacks.io/hackathon/portaldot-hacker-house-2026/detail#key-dates)**为准，日期记录见[排期观察](evidence/event-schedule-20261013.json)。Office Hours 申请、场次及后续演示/投票/领奖日期已与此前观察不同，本表采用新排期；开发期、Check-in 与最终截止没有改变。官方 Check-in 截止为 10-24 12:00 UTC，最终截止/代码冻结为 11-06 04:00 UTC，分别对应北京时间 20:00 和 12:00。Office Hours、Demo Day、获奖公布与资料收集只有 UTC 日期，具体时段及北京时间场次仍待官方确认。

## M2A 离线执行范围

[离线执行校验](execution.md)只检查输入事实的内部一致性，以模拟示例和本地行为测试验证。六项完整时 evidenceComplete=true，仍永久 fullVerification=false / verifiedNetwork=false / writeAllowed=false。此阶段不包含网络采集、运行时解码、探针、钱包或公开站更新；后续必须以真实 V3 身份、交易与固定区块读回证据验收。

## M2B 执行报告范围（2026-10-15）

M2B 核心 / CLI 提供严格版本化执行信封和 SHA-256 检查，兼容原始证据检查；完整导出与导入各限 1 MiB UTF-8，保留来源、原始时间、缺失 / 失败事实。最终代码 **3e7b607** / 文档 **d842530** 已于 **2026-10-15** 公开交付；最终聚焦 **139/139**、完整 **424/424**、类型检查与构建通过，52 个公开源码文件及源码 ZIP 经匿名远端字节回读一致。初始 117a84c 的 419/419 保留为历史检查点。所有执行永久 offline 且 verifiedNetwork / writeAllowed / fullVerification 为 false；M2B 没有部署执行网页或验证真实 V3。

真实 V3 配置与身份、运行时解码、探针、执行采集、固定最终区块读回、Check-in、视频 / Deck 和最终提交仍待完成。SHA-256 内容一致不能替代实链证据。项目仍在进行。

## M2C 离线执行网页交付（2026-10-16）

本地已有双视图、固定模拟、1 MiB 原始证据或严格报告 JSON 导入 / 粘贴、六阶段事实一致性报告、紧凑导出、打印入口及清空。两份状态独立保留，切换执行复核停止采集；错误保留有效报告，generation guard 拒绝过时完成。执行永久 offline 且三个验证 / 写入标志 false。初始 b54945c 对应完整 **453/453**；R1 修复 812a8e2 对应聚焦 **106/106** / 完整 **460/460**；本轮结果入口起始对齐的当前检查与提交单独记录于[开发证据](development-evidence.md)。

控制者在 812a8e2 的实际浏览器验证覆盖默认 M1 / 模拟、双状态切换保留（network best 105 与 RPC 来源执行报告）、六阶段 / 来源 / 原始时间 / uint64、新加载反馈、篡改拒绝并保留旧摘要、缺项 / 失败 / RPC 离线和三个 false 标志。390×844 下 inner / document / body 宽均 390，截图已检查并恢复视口。2511 字节下载、严格核心及文件选择器重导入仅归属 b54945c，没有在 R1 后重复宣称。

9b0f6e4 的当前聚焦106/全套460及类型/构建通过，f8249d3 实现检查点已公开；对齐后桌面和390px键盘定位已实测。原公开 Site 站点发布版本3已部署 succeeded/public，匿名 HTTP200 与新版 JS/CSS 字节匹配；线上模拟入口和来源/时间/序号/摘要已实际回读。10/16后来补验实际 A4 打印五种场景26页，包括65块祖先链14页；一次控制 WebCrypto 摘要延迟的导出→清空→释放交互，在摘要完成后无旧下载。源码未改，旧测试归属不变。八页原型 Deck 与92秒无声英文字幕截图讲解已准备；视频不是连续操作录屏或实链证明。认可 V3 / 运行时 / 账户映射 / 测试币 / 探针 / live 执行与回读、最终实链视频、Check-in 和最终提交继续待完成。

## 比赛期与代码记录

核心代码必须主要在 **2026-10-14 00:00–2026-11-06 12:00 Asia/Shanghai** 比赛期间产生。准备提交不计作比赛要求的至少三次有效比赛期代码提交；后续保留真实 commit / PR 时间线，仓库在比赛期间保持公开。不能将既有完整项目提交为本届作品，使用的框架、SDK、第三方依赖须披露来源。核心模块最终版本不能在截止前最后 24 小时一次性集中提交。

代码冻结后不能实质改变核心功能、架构或评审结果。严重缺陷如必须修复，应向主办方说明并保留清楚的修改记录；代码冻结并不自动授予修改许可。[官方代码要求](https://dorahacks.io/hackathon/portaldot-hacker-house-2026/detail)。

## 进入实施的条件

2026-10-14 已按有边界的实施计划完成本地只读代码与测试，后续继续按[设计](design.md)推进可独立完成的只读接入、错误处理、报告和界面。测试网暂时不可达时仍可实施这些模块，模拟记录须明确标注，不能作为真实测试网验证。真实部署与探针写入前，必须确认 V3 RPC、网络身份、测试币路径及到账、浏览器或等效查询和合约工具链；随后以[验收标准](acceptance.md)和[提交清单](submission-checklist.md)逐项留存真实证据。现有准备文档和主网观测不能证明应用或 V3 测试网已完成。
